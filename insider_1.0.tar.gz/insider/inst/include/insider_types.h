#ifndef __INSIDER_TYPE__
#define __INSIDER_TYPE__

#define ARMA_USE_BLAS 1
#define ARMA_USE_LAPACK 1

#include <RcppArmadillo.h>

using namespace arma;

#endif
