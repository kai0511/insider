#ifndef UTILS_HPP
#define UTILS_HPP

#include <RcppArmadillo.h>

using namespace arma;

void predict(const mat& row_factor, const mat& column_factor, mat& predictions);

void evaluate(const mat& data, const mat& predictions, mat& diff, 
              const uvec& train_idx, const uvec& test_idx, double& sum_residual, 
              double& train_rmse, double& test_rmse, const int& tuning, 
              const int& iter /* = 0*/, const int& verbose /*= 1*/);

double compute_loss(const mat& cfd_factor, const mat& column_factor, 
                    const double& lambda, const double& alpha, 
                    double& sum_residual, const int& verbose /*= 1*/);

#endif
