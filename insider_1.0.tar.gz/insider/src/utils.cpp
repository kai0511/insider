// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins("cpp11")]]

#define ARMA_USE_BLAS 1
#define ARMA_USE_LAPACK 1

#include <iostream>
#include <RcppArmadillo.h>
#include "utils.h"

using namespace arma;
using std::pow;

void predict(const mat& row_factor, const mat& column_factor, mat& predictions) {
    predictions = row_factor * column_factor;
}

void evaluate(const mat& data, const mat& predictions, mat& diff, const uvec& train_idx, const uvec& test_idx, 
              double& sum_residual, double& train_rmse, double& test_rmse, const int& tuning, 
              const int& iter = 0, const int& verbose = 1){

    diff = data - predictions;
    sum_residual = sum(square(diff.elem(train_idx)));
    train_rmse = std::sqrt(sum_residual/train_idx.n_elem);

    if(tuning == 1){
        test_rmse = std::sqrt(mean(square(diff.elem(test_idx))));
    }  

    if (verbose == 1){
        cout << "ibiasedMF with L1_penalty iter " << iter << ": train rmse = " << train_rmse << '\n' << endl;

        if(tuning == 1){
            cout << "ibiasedMF with L1_penalty iter " << iter << ": train rmse = " << test_rmse << '\n' << endl;
        }
    }
}

double compute_loss(const mat& cfd_factor, const mat& column_factor, const double& lambda, const double& alpha, 
                    double& sum_residual, const int& verbose = 1){

    // l2 penalty 
    double row_reg = lambda * pow(norm(cfd_factor, "F"), 2);
    double col_reg = lambda * (1 - alpha) * pow(norm(column_factor, "F"), 2);
    
    //  l1 penalty
    double l1_reg = lambda * alpha * sum(sum(abs(column_factor), 1));

    double loss = sum_residual/2 + row_reg/2 + col_reg/2 + l1_reg;

    if(verbose == 1) {
        cout << "total_residual" << '\t' << sum_residual/2 << ";" << '\n'
             << "row_reg_loss:" << '\t' << row_reg/2 << ";" << '\n'
             << "col_reg_loss:" << '\t' << col_reg/2 << ";" << '\n'
             << "l1_reg_loss:" << '\t' << l1_reg << "." << endl;
    }
    return loss;
}
