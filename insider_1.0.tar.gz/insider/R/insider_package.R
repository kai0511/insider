#' @useDynLib insider, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
